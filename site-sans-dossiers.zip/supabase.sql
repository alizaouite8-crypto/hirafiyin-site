-- ============================================================
-- HIRAFIYIN : base de données + sécurité
-- À lancer UNE SEULE FOIS : Supabase -> SQL Editor -> coller -> Run
-- AVANT de lancer : remplacer ADMIN_EMAIL (en minuscules) dans is_admin()
-- Pour 2 admins : array['a@x.com','b@y.com']
-- ============================================================

-- 0) Qui est admin (un seul endroit à modifier)
create or replace function public.is_admin() returns boolean
language sql stable as $$
  select coalesce(auth.jwt() ->> 'email', '') = any (array['ADMIN_EMAIL'])
$$;

-- 1) Tables (limites de taille et formats : on n'accepte que des données propres)
create table if not exists public.trainings (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 2 and 150),
  description text check (char_length(description) <= 2000),
  date date not null,
  place text check (char_length(place) <= 120),
  seats int check (seats between 0 and 10000),
  image_url text check (char_length(image_url) <= 500),
  created_at timestamptz not null default now()
);
create table if not exists public.partners (
  id uuid primary key default gen_random_uuid(),
  name text not null check (char_length(name) between 2 and 120),
  link text check (char_length(link) <= 300),
  logo_url text check (char_length(logo_url) <= 500),
  created_at timestamptz not null default now()
);
create table if not exists public.members (
  id uuid primary key default gen_random_uuid(),
  kind text not null check (kind in ('artisan','supplier')),
  name text not null check (char_length(name) between 2 and 100),
  phone text not null check (phone ~ '^(\+?212|0)[5-7][0-9]{8}$'),
  city text check (char_length(city) <= 80),
  craft text check (char_length(craft) <= 60),
  status text not null default 'pending' check (status in ('pending','accepted','refused')),
  created_at timestamptz not null default now()
);
create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  training_id uuid not null references public.trainings(id) on delete cascade,
  name text not null check (char_length(name) between 2 and 100),
  phone text not null check (phone ~ '^(\+?212|0)[5-7][0-9]{8}$'),
  city text check (char_length(city) <= 80),
  status text not null default 'pending' check (status in ('pending','accepted','refused')),
  created_at timestamptz not null default now(),
  unique (training_id, phone)
);
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  company text not null check (char_length(company) between 2 and 100),
  phone text not null check (phone ~ '^(\+?212|0)[5-7][0-9]{8}$'),
  name text not null check (char_length(name) between 2 and 120),
  price text check (char_length(price) <= 40),
  description text check (char_length(description) <= 1000),
  image_url text check (char_length(image_url) <= 500),
  status text not null default 'pending' check (status in ('pending','accepted','refused')),
  created_at timestamptz not null default now()
);

-- 2) Anti-spam : max 5 envois / heure / numéro et 100 envois / 10 min au total
create or replace function public.limit_public_inserts() returns trigger
language plpgsql security definer set search_path = public as $$
declare per_phone int; recent int;
begin
  if public.is_admin() then return new; end if;
  execute format('select count(*) from public.%I where phone = $1 and created_at > now() - interval ''1 hour''', tg_table_name) into per_phone using new.phone;
  execute format('select count(*) from public.%I where created_at > now() - interval ''10 minutes''', tg_table_name) into recent;
  if per_phone >= 5 or recent >= 100 then raise exception 'too many requests'; end if;
  return new;
end $$;

drop trigger if exists limit_members on public.members;
create trigger limit_members before insert on public.members for each row execute function public.limit_public_inserts();
drop trigger if exists limit_registrations on public.registrations;
create trigger limit_registrations before insert on public.registrations for each row execute function public.limit_public_inserts();
drop trigger if exists limit_products on public.products;
create trigger limit_products before insert on public.products for each row execute function public.limit_public_inserts();

-- 3) Droits (RLS) : tout fermé par défaut, on ouvre le strict nécessaire
alter table public.trainings enable row level security;
alter table public.partners enable row level security;
alter table public.members enable row level security;
alter table public.registrations enable row level security;
alter table public.products enable row level security;

-- le public LIT : formations, partenaires, produits validés
drop policy if exists "read trainings" on public.trainings;
create policy "read trainings" on public.trainings for select using (true);
drop policy if exists "read partners" on public.partners;
create policy "read partners" on public.partners for select using (true);
drop policy if exists "read products" on public.products;
create policy "read products" on public.products for select using (status = 'accepted');

-- le public ENVOIE seulement des demandes « en attente » (il ne lit jamais les inscrits)
drop policy if exists "join members" on public.members;
create policy "join members" on public.members for insert to anon with check (status = 'pending');
drop policy if exists "join trainings" on public.registrations;
create policy "join trainings" on public.registrations for insert to anon with check (status = 'pending');
drop policy if exists "submit products" on public.products;
create policy "submit products" on public.products for insert to anon with check (status = 'pending');

-- l'ADMIN (et lui seul) peut tout lire / modifier / supprimer
drop policy if exists "admin trainings" on public.trainings;
create policy "admin trainings" on public.trainings for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin partners" on public.partners;
create policy "admin partners" on public.partners for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin members" on public.members;
create policy "admin members" on public.members for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin registrations" on public.registrations;
create policy "admin registrations" on public.registrations for all to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists "admin products" on public.products;
create policy "admin products" on public.products for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- 4) Photos : jpg/png/webp seulement, taille limitée
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('images',   'images',   true, 5242880, array['image/jpeg','image/png','image/webp']),
  ('products', 'products', true, 2097152, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set public = true, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "admin images" on storage.objects;
create policy "admin images" on storage.objects for all to authenticated
  using (bucket_id = 'images' and public.is_admin()) with check (bucket_id = 'images' and public.is_admin());
drop policy if exists "anon upload products" on storage.objects;
create policy "anon upload products" on storage.objects for insert to anon with check (bucket_id = 'products');
drop policy if exists "admin products img" on storage.objects;
create policy "admin products img" on storage.objects for all to authenticated
  using (bucket_id = 'products' and public.is_admin()) with check (bucket_id = 'products' and public.is_admin());
