# HIRAFIYIN — site de l'association

Site statique (`index.html`) + base de données **Supabase** (gratuit). Pas de build : on pousse sur GitHub, Vercel publie.

## 1. Supabase (une seule fois)
1. Créer un projet sur supabase.com.
2. Ouvrir `supabase.sql`, remplacer `ADMIN_EMAIL` (en minuscules) par l'e-mail de l'admin, puis coller tout le fichier dans **SQL Editor** → **Run**.
3. **Authentication → Users → Add user** : créer le compte admin (même e-mail + un mot de passe long choisi par lui, jamais partagé).
4. **Authentication → Providers → Email** : désactiver « Allow new users to sign up ».
5. **Project Settings → API** : copier `Project URL` et la clé `anon public` dans `CFG` en haut du script de `index.html`.

## 2. GitHub + Vercel
Mettre tous les fichiers dans un repo GitHub, puis Vercel → Add New Project → ce repo → Deploy. `vercel.json` ajoute les en-têtes de sécurité automatiquement.

## 3. Utilisation
- Admin : `votre-site/#/admin` (bouton « دخول الإدارة » dans le menu).
- Formations (avec photo), partenaires, validation des inscriptions et des produits (bouton « قبول + واتساب » : message WhatsApp déjà écrit).
- Photos/vidéos des activités : dossiers `images/gallery/` et `videos/`, listes `GAL` / `VIDS` dans `index.html`.

## 4. Sécurité : ce qui est en place
- **Droits (RLS)** : le public lit seulement formations, partenaires et produits validés ; il ne lit jamais les inscrits ni leurs numéros. Seul l'e-mail admin peut modifier (fonction `is_admin()`), même si quelqu'un créait un compte.
- **Validation côté base** : longueurs, format du téléphone marocain, une seule inscription par numéro et par formation.
- **Anti-spam** : 5 envois/heure/numéro et 100/10 min au total ; champ piège invisible contre les robots ; photos jpg/png/webp, 2–5 Mo max.
- **Validation par l'admin** avant publication des produits.
- **En-têtes HTTP** (`vercel.json`) : CSP, anti-clickjacking, HTTPS forcé.
- Seule la clé `anon public` est dans le site. **Jamais** la clé `service_role`.

## 5. Checklist
- [ ] `ADMIN_EMAIL` remplacé dans `supabase.sql`
- [ ] Inscriptions (sign-ups) désactivées
- [ ] Mot de passe admin long, connu de lui seul
- [ ] Sauvegarde de temps en temps (Database → Backups ou export CSV)
- [ ] Si faux formulaires : activer le CAPTCHA (Authentication → Attack Protection)
