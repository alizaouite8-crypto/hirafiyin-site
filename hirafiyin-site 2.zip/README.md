# HIRAFIYIN — site de l'association

Site statique (`index.html`) + base de données Supabase (gratuit). Pas de build : on pousse sur GitHub, Vercel publie.

## 1. Supabase
1. Créer un projet sur supabase.com.
2. **SQL Editor** → coller et lancer :

```sql
create table trainings (id uuid primary key default gen_random_uuid(), title text not null, description text, date date not null, place text, seats int, image_url text, created_at timestamptz default now());
create table partners (id uuid primary key default gen_random_uuid(), name text not null, link text, logo_url text, created_at timestamptz default now());
create table members (id uuid primary key default gen_random_uuid(), kind text check (kind in ('artisan','supplier')), name text not null, phone text not null, city text, craft text, status text default 'pending', created_at timestamptz default now());
create table registrations (id uuid primary key default gen_random_uuid(), training_id uuid references trainings on delete cascade, name text not null, phone text not null, city text, status text default 'pending', created_at timestamptz default now());

alter table trainings enable row level security;
alter table partners enable row level security;
alter table members enable row level security;
alter table registrations enable row level security;

-- le public lit seulement formations et partenaires
create policy "read trainings" on trainings for select using (true);
create policy "read partners" on partners for select using (true);
-- le public peut seulement s'inscrire (jamais lire les inscrits)
create policy "join members" on members for insert to anon with check (status = 'pending');
create policy "join trainings" on registrations for insert to anon with check (status = 'pending');
-- l'admin (connecté) peut tout faire
create policy "admin trainings" on trainings for all to authenticated using (true) with check (true);
create policy "admin partners" on partners for all to authenticated using (true) with check (true);
create policy "admin members" on members for all to authenticated using (true) with check (true);
create policy "admin registrations" on registrations for all to authenticated using (true) with check (true);

create table products (id uuid primary key default gen_random_uuid(), company text not null, phone text not null, name text not null, price text, description text, image_url text, status text default 'pending', created_at timestamptz default now());
alter table products enable row level security;
create policy "read products" on products for select using (status = 'accepted');
create policy "submit products" on products for insert to anon with check (status = 'pending');
create policy "admin products" on products for all to authenticated using (true) with check (true);
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values ('products','products',true,2097152,array['image/jpeg','image/png','image/webp']);
create policy "anon upload products" on storage.objects for insert to anon with check (bucket_id = 'products');
create policy "admin delete products img" on storage.objects for delete to authenticated using (bucket_id = 'products');

-- bucket public pour les photos
insert into storage.buckets (id, name, public) values ('images','images',true);
create policy "admin upload" on storage.objects for insert to authenticated with check (bucket_id = 'images');
create policy "admin delete img" on storage.objects for delete to authenticated using (bucket_id = 'images');
```

3. **Authentication → Users → Add user** : créer le compte admin avec l'e-mail de l'admin et un mot de passe choisi par lui (ne jamais le partager).
4. **Authentication → Providers → Email** : désactiver « Allow new users to sign up » (sinon n'importe qui peut devenir admin).
5. **Project Settings → API** : copier `Project URL` et la clé `anon public`, les coller dans `CFG` en haut du script de `index.html`.

## 2. GitHub + Vercel
1. Créer un repo, y mettre `index.html` et `README.md`.
2. Sur Vercel : Add New Project → importer le repo → Deploy (aucun réglage).
3. Chaque `git push` met le site à jour.

## 3. Utilisation
- Admin : `votre-site/#/admin`.
- **Formations** : ajouter titre, date, lieu, photo. Les formations passées disparaissent toutes seules du site.
- **Tasjilat** : bouton « قبول + واتساب » ouvre WhatsApp avec le message de confirmation déjà écrit vers le numéro de la personne, puis marque le statut « accepté ».
- **Partenaires** : nom, lien, logo.
